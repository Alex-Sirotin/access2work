#!/bin/sh

echo "--------------------------------------------------------------------"
echo
echo "SoftEther VPN Client (Ver 4.44, Build 9807, Intel x64 / AMD64) for Linux Build Utility"
echo "Copyright (c) SoftEther Project at University of Tsukuba, Japan. All Rights Reserved."
echo
echo "--------------------------------------------------------------------"
echo
echo

cat ReadMeFirst_License.txt

echo
echo "--------------------------------------------------------------------"
echo
echo

make main

exit 0

